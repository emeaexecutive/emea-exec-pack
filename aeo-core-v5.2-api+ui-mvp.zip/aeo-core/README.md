![CI](../../actions/workflows/ci.yml/badge.svg)

# AEO — Automated Executive Outreach (v5.2)

AEO is a multi-agent system by **EMEA EXECUTIVES** for transparent, fair executive hiring across EMEA.

## 🌌 The AEO Constellation
- **Orion** — candidate-fit intelligence & explainable scoring
- **Vega** — client-role matching & prioritisation
- **Lyra** — market intelligence & competitive signals
- **Atlas** — research, mapping & executive landscape coverage
- **Nova** — outreach, follow-ups & engagement orchestration

## What’s included
- Express API (TypeScript, ESM)
- Consent ledger (tamper-evident chain)
- Audit middleware
- Explainable scoring snapshots
- Coinbase Commerce crypto payments
- PDF export (Puppeteer)
- OpenAPI + Postman
- Docker + docker-compose (Postgres)
- GitHub Actions CI

## Quickstart
```bash
npm install
cp .env.example .env
docker compose up -d
npm run dev
```

## Build + test
```bash
npm run build
npm test
```

## Docs
- OpenAPI: `docs/openapi.yaml`
- Postman: `docs/postman_collection.json`


## MVP Run (API + UI)
```bash
npm install
cp .env.example .env
docker compose up -d
npm run migrate
npm run seed
npm run dev
```

Open:
- API health: http://localhost:8080/health
- UI dashboard: http://localhost:8080/ui/
