import { Pool } from "pg";
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
async function run(){
  const c = await pool.connect();
  try{
    await c.query("begin");
    await c.query("select 1");
    await c.query("commit");
    console.log("Seed complete (db reachable).");
  }catch(e){
    await c.query("rollback");
    console.error(e);
    process.exitCode = 1;
  }finally{
    c.release();
    await pool.end();
  }
}
run();
