import fs from "fs";
import path from "path";
import { Pool } from "pg";
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function run(){
  const sqlPath = path.join(process.cwd(), "db/migrations/01_core.sql");
  const sql = fs.readFileSync(sqlPath, "utf8");
  const c = await pool.connect();
  try{
    await c.query("begin");
    await c.query(sql);
    await c.query("commit");
    console.log("Migration applied:", sqlPath);
  }catch(e){
    await c.query("rollback");
    console.error("Migration failed:", e);
    process.exitCode = 1;
  }finally{
    c.release();
    await pool.end();
  }
}
run();
