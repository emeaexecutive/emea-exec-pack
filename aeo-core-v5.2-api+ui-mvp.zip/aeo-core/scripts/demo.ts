console.log("Demo: start the API, then open /health and docs/openapi.yaml");
