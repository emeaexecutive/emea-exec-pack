import fetch from "node-fetch";
const BASE = "https://api.commerce.coinbase.com";
export async function createCoinbaseCharge(params: { invoiceId:string; clientName:string; amount:string; currency:"GBP"|"EUR"; description?:string; redirectUrl?:string; cancelUrl?:string; }) {
  const apiKey = process.env.COINBASE_COMMERCE_API_KEY;
  if (!apiKey) throw new Error("Missing COINBASE_COMMERCE_API_KEY");
  const res = await fetch(`${BASE}/charges/`, {
    method:"POST",
    headers:{ "Content-Type":"application/json", "X-CC-Api-Key": apiKey, "X-CC-Version":"2018-03-22" },
    body: JSON.stringify({
      name: `EMEA EXECUTIVES — Invoice ${params.invoiceId}`,
      description: params.description ?? "Executive Search Services",
      local_price: { amount: params.amount, currency: params.currency },
      pricing_type: "fixed_price",
      metadata: { invoice_id: params.invoiceId, client_name: params.clientName },
      redirect_url: params.redirectUrl,
      cancel_url: params.cancelUrl
    })
  });
  if(!res.ok){ const t = await res.text(); throw new Error(`Coinbase charge create failed: ${res.status} ${t}`); }
  const j:any = await res.json();
  return { chargeCode: j.data.code, hostedUrl: j.data.hosted_url, expiresAt: j.data.expires_at };
}
