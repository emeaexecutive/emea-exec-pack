import { Pool } from "pg";
export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export async function pingDb(){ const c = await pool.connect(); try{ await c.query("select 1"); return true; } finally{ c.release(); } }
