import { Router, Request, Response } from "express";
import { pool } from "../db.js";
import { createCoinbaseCharge } from "../payments/coinbaseCommerce.js";
export const invoicesRouter = Router();

invoicesRouter.post("/", async (req: Request, res: Response) => {
  try{
    const { clientName, currency, amountCents, dueDays } = req.body ?? {};
    if(!clientName || !currency || typeof amountCents !== "number") return res.status(400).json({ ok:false, error:"Missing required fields" });
    const dd = typeof dueDays === "number" ? dueDays : 30;
    const { rows } = await pool.query(
      `insert into invoices (client_name, currency, amount_cents, status, issue_date, due_date, notes)
       values ($1,$2,$3,'sent', current_date, current_date + ($4||' days')::interval, $5)
       returning id, client_name, currency, amount_cents, status, issue_date, due_date`,
      [clientName, currency, amountCents, dd, "30-day terms. Optional crypto via Coinbase Commerce."]
    );
    return res.json({ ok:true, invoice: rows[0] });
  }catch(e:any){ return res.status(500).json({ ok:false, error: e?.message ?? "Error" }); }
});

invoicesRouter.post("/:invoiceId/coinbase-charge", async (req: Request, res: Response) => {
  try{
    const invoiceId = req.params.invoiceId;
    const inv = await pool.query(`select id, client_name, currency, amount_cents from invoices where id=$1 limit 1`, [invoiceId]);
    if(!inv.rows[0]) return res.status(404).json({ ok:false, error:"Invoice not found" });
    const amount = (Number(inv.rows[0].amount_cents)/100).toFixed(2);
    const charge = await createCoinbaseCharge({ invoiceId, clientName: inv.rows[0].client_name, currency: inv.rows[0].currency, amount });
    await pool.query(
      `insert into crypto_payments (invoice_id, asset, amount_asset, fx_basis, fx_rate, address, txid, confirmations, status)
       values ($1,'MULTI',0,'fixed_price_charge',0,$2,null,0,'pending')`,
      [invoiceId, charge.hostedUrl]
    );
    return res.json({ ok:true, ...charge });
  }catch(e:any){ return res.status(500).json({ ok:false, error: e?.message ?? "Error" }); }
});
