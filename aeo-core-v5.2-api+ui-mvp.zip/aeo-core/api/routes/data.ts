import { Router, Request, Response } from "express";
import { pool } from "../db.js";
export const dataRouter = Router();

dataRouter.get("/companies", async (_req: Request, res: Response) => {
  const { rows } = await pool.query(`select id, name, hq_city, sector, website from companies order by name asc limit 200`);
  res.json({ ok:true, companies: rows });
});

dataRouter.get("/roles", async (_req: Request, res: Response) => {
  const { rows } = await pool.query(
    `select r.id, r.title, r.seniority, r.location, r.status, c.name as company
     from roles r left join companies c on c.id=r.company_id
     order by r.created_at desc limit 200`
  );
  res.json({ ok:true, roles: rows });
});

dataRouter.get("/candidates/:id", async (req: Request, res: Response) => {
  const { rows } = await pool.query(`select id, full_name, email, linkedin_url, location, seniority, created_at from candidates where id=$1 limit 1`, [req.params.id]);
  if(!rows[0]) return res.status(404).json({ ok:false, error:"Not found" });
  res.json({ ok:true, candidate: rows[0] });
});
