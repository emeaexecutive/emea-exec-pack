import { Router, Request, Response } from "express";
import { recordConsent, verifyChain } from "../services/consentLedger.js";
export const consentsRouter = Router();
consentsRouter.post("/", async (req: Request, res: Response) => {
  try{
    const { candidateId, purpose, channel, granted } = req.body ?? {};
    if (!candidateId || !purpose || !channel || typeof granted !== "boolean") return res.status(400).json({ ok:false, error:"Missing required fields" });
    const out = await recordConsent({ candidateId, purpose, channel, granted });
    return res.json({ ok:true, ...out });
  }catch(e:any){ return res.status(500).json({ ok:false, error: e?.message ?? "Error" }); }
});
consentsRouter.get("/:candidateId/verify", async (req: Request, res: Response) => {
  try{ return res.json(await verifyChain(req.params.candidateId)); }
  catch(e:any){ return res.status(500).json({ ok:false, error: e?.message ?? "Error" }); }
});
