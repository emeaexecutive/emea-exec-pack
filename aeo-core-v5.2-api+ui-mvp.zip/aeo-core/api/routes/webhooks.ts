import crypto from "crypto";
import { Router, Request, Response } from "express";
import { pool } from "../db.js";
export const webhooksRouter = Router();

function safeEq(a: string, b: string){
  const ab = Buffer.from(a, "utf8"); const bb = Buffer.from(b, "utf8");
  if(ab.length !== bb.length) return false;
  return crypto.timingSafeEqual(ab, bb);
}

webhooksRouter.post("/coinbase-commerce", async (req: Request, res: Response) => {
  try{
    const sig = (req.header("X-CC-Webhook-Signature") || "").trim();
    const secret = (process.env.COINBASE_COMMERCE_WEBHOOK_SECRET || "").trim();
    if(!sig || !secret) return res.status(400).send("Missing signature/secret");
    const rawBody = (req as any).rawBody as Buffer;
    if(!rawBody) return res.status(400).send("Missing raw body");
    const computed = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
    if(!safeEq(computed, sig)) return res.status(401).send("Invalid signature");

    const event = JSON.parse(rawBody.toString("utf8"));
    const eventType = event.event?.type;
    const data = event.event?.data;
    const invoiceId = data?.metadata?.invoice_id;

    if(invoiceId){
      await pool.query(
        `insert into audit_events (actor_id, actor_email, action, target_type, target_id, meta)
         values (null, 'coinbase-webhook', $1, 'invoice', $2, $3)`,
        [eventType || "webhook", invoiceId, event]
      );
    }

    if(eventType === "charge:confirmed" && invoiceId){
      await pool.query(`update invoices set status='paid' where id=$1`, [invoiceId]);
      await pool.query(`update crypto_payments set status='confirmed' where invoice_id=$1`, [invoiceId]);
    }
    return res.sendStatus(200);
  }catch{ return res.status(500).send("Webhook error"); }
});
