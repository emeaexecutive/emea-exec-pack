import { Router, Request, Response } from "express";
import { saveFitScore } from "../services/fitScoring.js";
export const fitScoresRouter = Router();
fitScoresRouter.post("/", async (req: Request, res: Response) => {
  try{
    const { candidateId, roleId, total, weights, evidence } = req.body ?? {};
    if (!candidateId || !roleId || typeof total !== "number" || !weights || !evidence) return res.status(400).json({ ok:false, error:"Missing required fields" });
    await saveFitScore(candidateId, roleId, { total, weights, evidence });
    return res.json({ ok:true });
  }catch(e:any){ return res.status(500).json({ ok:false, error: e?.message ?? "Error" }); }
});
