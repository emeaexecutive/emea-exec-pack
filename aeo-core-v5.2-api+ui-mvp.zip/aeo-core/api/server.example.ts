import express, { Request, Response } from "express";
import cors from "cors";
import helmet from "helmet";
import { pingDb } from "./db.js";
import { consentsRouter } from "./routes/consents.js";
import { fitScoresRouter } from "./routes/fitScores.js";
import { invoicesRouter } from "./routes/invoices.js";
import { webhooksRouter } from "./routes/webhooks.js";
import { dataRouter } from "./routes/data.js";

const app = express();
app.use(helmet());
app.use(cors());

// raw body for webhooks
app.use("/api/webhooks", express.raw({ type: "application/json" }), (req: any, _res, next) => {
  req.rawBody = req.body;
  next();
});

// json for others
app.use(express.json());

app.get("/health", async (_req: Request, res: Response) => {
  try { const db = await pingDb(); res.json({ ok: true, db }); }
  catch { res.json({ ok: true, db: false }); }
});

app.use("/api/consents", consentsRouter);
app.use("/api/fit-scores", fitScoresRouter);
app.use("/api/invoices", invoicesRouter);
app.use("/api/webhooks", webhooksRouter);
app.use("/api", dataRouter);

// Static UI
app.use("/ui", express.static(new URL("../web/ui", import.meta.url).pathname));

const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`AEO API listening on :${port}`));
