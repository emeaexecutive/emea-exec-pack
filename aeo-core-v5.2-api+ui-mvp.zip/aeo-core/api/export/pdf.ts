
import puppeteer from "puppeteer";
export async function renderPdfFromHtml(html: string, footerNote = "Confidential — EMEA EXECUTIVES") {
  const browser = await puppeteer.launch({ headless: "new" });
  const page = await browser.newPage();
  await page.setContent(html, { waitUntil: "networkidle0" });
  const pdf = await page.pdf({
    format: "A4",
    printBackground: true,
    displayHeaderFooter: true,
    footerTemplate: `<div style="font-size:9px;width:100%;text-align:center;color:#888;">${footerNote}</div>`,
    headerTemplate: `<div></div>`,
    margin: { top: "15mm", bottom: "15mm", left: "12mm", right: "12mm" }
  });
  await browser.close();
  return pdf;
}
