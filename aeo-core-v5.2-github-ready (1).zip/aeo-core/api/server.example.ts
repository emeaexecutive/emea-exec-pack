
import express, { type Request, type Response } from "express";
import { audit } from "./middleware/audit.js";
import { recordConsent, hasActiveOutreachConsent } from "./services/consentLedger.js";
const app = express();
app.use(express.json());

app.post(
  "/api/consents",
  audit("CREATE_CONSENT", (req) => ({ type: "candidate", id: String((req as any).body?.candidateId ?? "") })),
  async (req: Request, res: Response) => {
  const { candidateId, purpose, channel, granted } = req.body;
  const result = await recordConsent({ candidateId, purpose, channel, granted });
  res.json(result);
});

app.get("/api/outreach/eligible/:candidateId", audit("CHECK_OUTREACH"), async (req: Request, res: Response) => {
  const ok = await hasActiveOutreachConsent(req.params.candidateId);
  res.json({ candidateId: req.params.candidateId, eligible: ok });
});

app.get("/health", (_: Request, res: Response) => res.json({ ok: true }));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`AEO core server running on :${port}`));
