
export type Evidence = { dimension: "experience"|"outcomes"|"culture"; score: number; rationale: string; sources: string[] };
export type Weights = { experience: number; outcomes: number; culture: number };

export function scoreCandidate(input: {
  weights: Weights;
  experienceMatch: number; // 0..1
  outcomesMatch: number;   // 0..1
  cultureSignals: number;  // 0..1
  rationales: { experience: string; outcomes: string; culture: string };
  sources: { experience: string[]; outcomes: string[]; culture: string[] };
}) {
  const e: Evidence[] = [
    { dimension: "experience", score: input.experienceMatch, rationale: input.rationales.experience, sources: input.sources.experience },
    { dimension: "outcomes", score: input.outcomesMatch, rationale: input.rationales.outcomes, sources: input.sources.outcomes },
    { dimension: "culture", score: input.cultureSignals, rationale: input.rationales.culture, sources: input.sources.culture }
  ];
  const total = +(input.weights.experience*input.experienceMatch
                 +input.weights.outcomes*input.outcomesMatch
                 +input.weights.culture*input.cultureSignals).toFixed(3);
  return { total, weights: input.weights, evidence: e };
}
