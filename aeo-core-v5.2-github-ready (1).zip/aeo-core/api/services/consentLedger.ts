
import crypto from "crypto";
import { Pool } from "pg";
export const pool = new Pool({ connectionString: process.env.DATABASE_URL });

function sha256(s: string) { return crypto.createHash("sha256").update(s).digest("hex"); }

export async function recordConsent(params: {
  candidateId: string;
  purpose: "outreach" | "processing" | "share_with_client";
  channel: "email" | "linkedin" | "phone" | "webform";
  granted: boolean;
}) {
  const client = await pool.connect();
  try {
    await client.query("begin");
    const prev = await client.query(
      "select record_hash from consents where candidate_id=$1 order by timestamp desc limit 1",
      [params.candidateId]
    );
    const prevHash = prev.rows[0]?.record_hash ?? null;
    const ts = new Date().toISOString();
    const nonce = crypto.randomUUID();
    // Include a nonce so identical events at the same timestamp cannot collide.
    const payload = [params.candidateId, params.purpose, String(params.granted), ts, prevHash ?? "", nonce].join("|");
    const recordHash = sha256(payload);
    await client.query(
      `insert into consents (candidate_id,purpose,channel,granted,timestamp,nonce,prev_hash,record_hash)
       values ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [params.candidateId, params.purpose, params.channel, params.granted, ts, nonce, prevHash, recordHash]
    );
    await client.query("commit");
    return { ok: true, recordHash };
  } catch (e) {
    await client.query("rollback");
    throw e;
  } finally {
    client.release();
  }
}

export async function verifyChain(candidateId: string) {
  const { rows } = await pool.query(
    "select candidate_id,purpose,granted,timestamp,nonce,prev_hash,record_hash from consents where candidate_id=$1 order by timestamp asc",
    [candidateId]
  );
  let prev: string | null = null;
  for (const r of rows) {
    const ts = new Date(r.timestamp).toISOString();
    // 1) Ensure the stored prev_hash matches the actual previous record hash we observed.
    const expectedPrev = prev ?? null;
    if ((r.prev_hash ?? null) !== expectedPrev) return { ok: false, breakAt: r.record_hash, reason: "prev_hash_mismatch" as const };

    // 2) Recompute the record hash using the stored nonce.
    const payload = [r.candidate_id, r.purpose, String(r.granted), ts, expectedPrev ?? "", r.nonce].join("|");
    const calc = sha256(payload);
    if (calc !== r.record_hash) return { ok: false, breakAt: r.record_hash, reason: "hash_mismatch" as const };
    prev = r.record_hash;
  }
  return { ok: true };
}

export async function hasActiveOutreachConsent(candidateId: string): Promise<boolean> {
  const { rows } = await pool.query(
    "select granted from consents where candidate_id=$1 and purpose='outreach' order by timestamp desc limit 1",
    [candidateId]
  );
  return rows[0]?.granted === true;
}
