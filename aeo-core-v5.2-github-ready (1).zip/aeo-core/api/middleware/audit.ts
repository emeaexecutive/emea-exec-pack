
import { Request, Response, NextFunction } from "express";
import { Pool } from "pg";
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export function audit(action: string, getTarget?: (req: Request) => { type: string; id: string; meta?: any }) {
  return async (req: Request, res: Response, next: NextFunction) => {
    res.on("finish", async () => {
      try {
        const t = getTarget?.(req) ?? { type: null as any, id: null as any, meta: null };
        await pool.query(
          `insert into audit_events (actor_id, actor_email, action, target_type, target_id, meta, ip, user_agent)
           values ($1,$2,$3,$4,$5,$6,$7,$8)`,
          [
            (req as any).user?.id ?? null,
            (req as any).user?.email ?? null,
            action,
            t.type,
            t.id,
            t.meta ?? {},
            req.ip,
            req.headers["user-agent"] ?? null
          ]
        );
      } catch {}
    });
    next();
  };
}
