
export type Asset = "BTC" | "ETH" | "USDC";
export interface RateProvider {
  getFiatPerAsset(asset: Asset, fiat: "GBP"|"EUR"): Promise<number>;
}
export class CryptoInvoicer {
  constructor(private rate: RateProvider) {}
  async preparePayment(invoice: { id:string; currency:"GBP"|"EUR"; amountCents:number; }, asset: Asset) {
    const fx = await this.rate.getFiatPerAsset(asset, invoice.currency);
    const amountAsset = (invoice.amountCents / 100) / fx;
    return { amountAsset, fxRate: fx, fxBasis: "invoice_date_spot" };
  }
}
