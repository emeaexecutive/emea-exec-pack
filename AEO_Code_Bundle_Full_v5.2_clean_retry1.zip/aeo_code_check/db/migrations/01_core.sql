
create extension if not exists pgcrypto;
create extension if not exists "uuid-ossp";

-- Companies / Roles / Candidates
create table if not exists companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  hq_city text,
  sector text,
  website text
);
create table if not exists roles (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies(id) on delete cascade,
  title text not null,
  seniority text,
  location text,
  status text default 'open',
  created_at timestamptz default now()
);
create index if not exists idx_roles_company on roles(company_id);

create table if not exists candidates (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text unique,
  linkedin_url text,
  location text,
  seniority text,
  created_at timestamptz default now()
);

-- Consent ledger (append-only style, tamper-evident hash)
create table if not exists consents (
  id uuid primary key default gen_random_uuid(),
  candidate_id uuid not null references candidates(id) on delete cascade,
  purpose text not null check (purpose in ('outreach','processing','share_with_client')),
  channel text not null check (channel in ('email','linkedin','phone','webform')),
  granted boolean not null,
  timestamp timestamptz not null default now(),
  nonce text not null,
  prev_hash text,
  record_hash text not null
);
create index if not exists idx_consents_candidate_time on consents(candidate_id, timestamp desc);

-- Audit trail
create table if not exists audit_events (
  id bigserial primary key,
  actor_id uuid,
  actor_email text,
  action text not null,
  target_type text,
  target_id text,
  meta jsonb,
  ip inet,
  user_agent text,
  created_at timestamptz default now()
);
create index if not exists idx_audit_time on audit_events(created_at desc);

-- Fit scores
create table if not exists fit_scores (
  id uuid primary key default gen_random_uuid(),
  candidate_id uuid not null references candidates(id) on delete cascade,
  role_id uuid not null references roles(id) on delete cascade,
  total numeric not null,
  weights jsonb not null,
  evidence jsonb not null,
  created_at timestamptz default now()
);
create index if not exists idx_fit_scores_candidate_role on fit_scores(candidate_id, role_id);

-- Invoices and crypto payments
create table if not exists invoices (
  id uuid primary key default gen_random_uuid(),
  client_name text not null,
  currency text not null check (currency in ('GBP','EUR')),
  amount_cents bigint not null,
  status text not null default 'draft' check (status in ('draft','sent','paid','failed')),
  issue_date date not null default current_date,
  due_date date not null,
  notes text
);

create table if not exists crypto_payments (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid references invoices(id) on delete cascade,
  asset text not null check (asset in ('BTC','ETH','USDC')),
  amount_asset numeric not null,
  fx_basis text not null default 'invoice_date_spot',
  fx_rate numeric not null,
  address text not null,
  txid text,
  confirmations int default 0,
  status text not null default 'pending' check (status in ('pending','confirmed','failed')),
  created_at timestamptz default now()
);
create index if not exists idx_crypto_invoice on crypto_payments(invoice_id);
