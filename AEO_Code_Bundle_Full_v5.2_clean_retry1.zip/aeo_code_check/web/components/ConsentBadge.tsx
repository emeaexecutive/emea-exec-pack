
import React from "react";
export function ConsentBadge({ granted }: { granted: boolean }) {
  return (
    <span className={
      `inline-flex items-center px-2 py-1 rounded-full text-xs ${granted ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"}`
    }>
      {granted ? "Consent: Active" : "Consent: Missing"}
    </span>
  );
}
