
import React from "react";
type Evidence = { dimension:string; score:number; rationale:string; sources:string[] };
export function ScoreExplain({ total, weights, evidence }:{
  total:number; weights:{experience:number; outcomes:number; culture:number}; evidence:Evidence[];
}) {
  return (
    <div className="rounded-xl border p-4">
      <div className="text-sm text-slate-500">Match-fit score</div>
      <div className="text-3xl font-semibold">{Math.round(total*100)} / 100</div>
      <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
        {evidence.map((e)=>(
          <div key={e.dimension} className="rounded-lg bg-slate-50 p-3">
            <div className="font-medium">{e.dimension} · {(weights as any)[e.dimension]*100}%</div>
            <div className="text-slate-600 mt-1">Score: {Math.round(e.score*100)}%</div>
            <div className="text-slate-500 mt-1">{e.rationale}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
