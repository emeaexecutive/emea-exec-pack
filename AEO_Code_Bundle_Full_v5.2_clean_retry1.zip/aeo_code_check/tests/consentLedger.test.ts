
/**
 * Adjust DB handling for your env and seed a test candidate id before running.
 */
import { recordConsent, verifyChain } from "../api/services/consentLedger";

test("consent chain remains valid", async () => {
  const cid = "00000000-0000-0000-0000-000000000001";
  await recordConsent({ candidateId: cid, purpose:"outreach", channel:"email", granted:true });
  await recordConsent({ candidateId: cid, purpose:"processing", channel:"webform", granted:true });
  const ok = await verifyChain(cid);
  expect(ok.ok).toBe(true);
});
