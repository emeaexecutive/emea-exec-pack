
# AEO – Core Modules (Production‑Ready)

This bundle ships working modules for consent logging (tamper‑evident), audit trail, explainable fit scoring, crypto invoicing scaffolding, and HTML→PDF exporting, plus React components and SQL migrations.

## Structure
```
/api
  /middleware/audit.ts
  /services/consentLedger.ts
  /services/fitScoring.ts
  /payments/crypto.ts
  /export/pdf.ts
  /server.example.ts
/db/migrations
  /01_core.sql
/tests
  /consentLedger.test.ts
/web/components
  /ConsentBadge.tsx
  /ScoreExplain.tsx
.env.example
package.json
tsconfig.json
tsconfig.api.json
tsconfig.web.json
jest.config.cjs
```

## Quick start
1) **DB migrate**
   Apply `db/migrations/01_core.sql` to Postgres.
2) **Install deps**
```bash
npm i express pg puppeteer
npm i -D typescript ts-node @types/node @types/express jest ts-jest @types/jest
```
3) **Configure env**
Copy `.env.example` → `.env` and set secrets/DB.
4) **Run**
```bash
ts-node api/server.example.ts
```
5) **Tests**
```bash
npm run test
```

## Notes
- The consent ledger uses an append-only hash chain. Each record stores a per-entry `nonce` so replays/collisions cannot occur, and `verifyChain()` validates both the hash and the `prev_hash` linkage.
- `npm run build` compiles API modules only. If you want to type-check the React components, run `npm run build:web`.

> Security: Enforce RBAC, mask PII in logs, rate‑limit export endpoints, and store crypto FX rates at invoice time.
